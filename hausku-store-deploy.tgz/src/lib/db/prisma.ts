import "server-only";
import fs from "node:fs";
import path from "node:path";
import { PrismaClient } from "@prisma/client";

// ── Robust SQLite path resolution ─────────────────────────────────────────
// Prisma resolves relative "file:" URLs against its own schema copy, which can
// point to the wrong location on managed hosts (e.g. Hostinger) or when the
// .env file isn't loaded. We resolve the database path to an ABSOLUTE path
// anchored on the project root so runtime queries always find prisma/dev.db.
function resolveDatabaseUrl(): string | undefined {
  const raw = (process.env.DATABASE_URL || "file:./dev.db").trim();
  if (!raw.startsWith("file:")) return raw; // non-SQLite or absolute URL — leave as-is
  const [relPath, query = ""] = raw.slice("file:".length).split("?");
  if (path.isAbsolute(relPath)) return raw; // already absolute — keep it
  const prismaDir = path.resolve(process.cwd(), "prisma");
  const absPath = path.join(prismaDir, relPath.replace(/^\.\//, ""));
  return `file:${absPath}${query ? `?${query}` : ""}`;
}

const resolvedUrl = resolveDatabaseUrl();
process.env.DATABASE_URL = resolvedUrl;

// Log a clear warning if the SQLite file is missing — Prisma would otherwise
// silently create an EMPTY database and queries would fail with
// "table does not exist", which is hard to diagnose in production.
if (resolvedUrl?.startsWith("file:")) {
  const dbPath = resolvedUrl.slice("file:".length).split("?")[0];
  if (!fs.existsSync(dbPath)) {
    console.error(
      `[prisma] WARNING: SQLite database not found at ${dbPath}. ` +
        `Prisma will create an empty database and tables will be missing.`
    );
  }
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
